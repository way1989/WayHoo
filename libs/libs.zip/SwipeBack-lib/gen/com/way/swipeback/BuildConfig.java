/** Automatically generated file. DO NOT MODIFY */
package com.way.swipeback;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}